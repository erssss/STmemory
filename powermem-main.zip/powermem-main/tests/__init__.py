"""
Test module initialization
"""
