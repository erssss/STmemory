"""
Unit tests module initialization
"""
