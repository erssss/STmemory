"""
Integration tests module initialization
"""
